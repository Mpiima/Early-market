<?php

date_default_timezone_set('Africa/Kampala');

if (isset($_GET['selector'])){$selector=$_GET['selector'];} 
elseif (isset($_POST['selector'])){$selector=$_POST['selector'];} 
elseif (isset($altselector)){$selector=$altselector;}
else{$selector= ""; }

$goodreceivers="and status='active' and email!=''";

function mailtrigger()
{

global $to;
global $subject;
global $message;
$headers = 'From: system@acfim.eastafrica.website' . "\r\n" .
'Reply-To: system@acfim.eastafrica.website' . "\r\n" .
'X-Mailer: PHP/' . phpversion();
$headers .= "MIME-Version: 1.0\r\n";
$headers .= 'Cc: maillog@tabiecrm.com' . "\r\n";
$headers .= "Content-Type: text/html; charset=UTF-8\r\n";
mail($to, $subject, $message, $headers);
}

if ($selector=="performancemail")
{$send=1;
include("performancemail.php");
}

?>