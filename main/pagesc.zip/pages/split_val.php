<?php
$val=$_POST["val"];

if(!empty($val)){
$result_scrap=$dbh->query("select * from scrap where item3='$val' and type='prodcat'");
$row_scrap=$result_scrap->fetchObject();
$count_scrap=$result_scrap->rowCount(); 
echo "
<select class='form-control' id='subcatid' name='subcatid'>
<option value=''>Select Category</option>";

if($count_scrap>0){  do{ 
echo "<option value='".$row_scrap->item."'>".$row_scrap->item2."</option>";
}while($row_scrap=$result_scrap->fetchObject()); }
else{echo "<option value=''>There Are No Empty Units.</option>";}

echo "</select>";}
?>