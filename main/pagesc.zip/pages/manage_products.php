<?php include("kfunctions.php"); ?>
<!DOCTYPE html>
<html lang="en">

<head>
<?php kheader(); ?>
</head>

<body class="">
<?php leftbar(); ?>

<div class="row">

<div class=" col-md-12">
<div class="card">
<div class="card-header card-header-primary">
<h4 class="card-title">Posted Ads</h4>

</div>
<div class="card-body table-responsive">

</div>
</div>
</div>
</div>
<?php lscript(); ?>
</body>

</html>
