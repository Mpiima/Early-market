<?php include("kfunctions.php"); ?>
<!DOCTYPE html>
<html lang="en">

<head>
<?php kheader(); ?>
</head>

<body class="">
<?php leftbar(); ?>

<div class="col-md-12">
<div class="card">
<div class="card-header card-header-primary">
<h4 class="card-title "><b>PODUCT STATISTICS</b></h4>
</div>
<div class="card-body">
<table class="table table-striped table-bordered">
<thead>
<tr>
<th><b>No</b></th>
<th><b>Product Details</b></th>
<th><b>Seller</b></th>
<th><b>Today's Views</b></th>
<th><b>Weekly Views</b></th>
<th><b>Monthly Views</b></th>
<th><b>Action</b></th>
</tr></thead>

</table>
</div>
</div>
</div>
</div>
</div>

<?php lscript(); ?>
</body>

</html>
